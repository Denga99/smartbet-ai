# SmartBet AI

Football predictions powered by Next.js
